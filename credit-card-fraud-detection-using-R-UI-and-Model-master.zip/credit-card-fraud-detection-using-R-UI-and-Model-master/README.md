# credit-card-fraud-detection-using-R-UI-and-Model
Model is created in the fraud-detection.R file using decision trees 
Rest of the files are for UI and it uses XGBOOST algorithm for model building
